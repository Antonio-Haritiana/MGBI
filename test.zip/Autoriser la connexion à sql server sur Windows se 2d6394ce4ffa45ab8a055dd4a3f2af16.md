# Autoriser la connexion à sql server sur Windows server (focicom) (1/2/24)

Problème:

L’équipe dev veut effectuer une connexion à sql server (base de donné) mais n’y arrive pas 

Cause:

Présence d’un pare-feu n’y autorisant pas la connexion à la base de donnée

Solution:

<aside>
💡 [https://www.apesoftware.com/calibration-control/help/sql-remote-connections](https://www.apesoftware.com/calibration-control/help/sql-remote-connections)

</aside>

Etapes

- Ouvrir **SQL Server Management Studio**
    - clique droite sur le nom du serveur (c’est la première ligne des liste affiché par **SQL Server Management Studio**)
    
    ![Untitled](Untitled.png)
    
- Dans l’onglet “Connexions”, cocher la case “autoriser la connexion à distance à ce serveur”
    
    ![Untitled](Untitled%201.png)
    
- Ouvrir **SQL Server Configuration Manager**
    - choisir l’option “configuration du réseau SQL server”
    - Protocole pour [nom_du_serveur:dans notre cas EBP]:
        
        > NB: SQL SERVER: logiciel de stockage de données à partir des bases enrégistrées dedans
        > 
        
        > SQL server peut avoir plusieurs instances (instance sql server: otran hoe mi-démarre sql maromaro), ces instances peuvent avoir leurs propres règles: comme sur la photo ci-dessous, l’image possède différents protocoles pour chaque instance (Protocols for …, )
        > 
        > 
        > > Ces instances peuvent être nommés (selon les bases enrégistrés dedans): dans notre cas, elle est nommé EBP ( car c’est la base de donnée d’EBP), on peut égalment le nommé EBP2019 (selon les versions d’EBP)
        > > 
        
    - clique droit sur TCP/IP, puis “enable”
    - clique droit sur TCP/IP, puis “propriété”
        - rechercher “IPAII”
        - entrer le port 1433 dans la case “TCP port field”
        
        ![Untitled](Untitled%202.png)
        
        ![Untitled](Untitled%203.png)
        
- Dans SQL Server Services dialog, clique droit sur le nom du serveur puis redémarrer (dans notre cas “SQL server EBP”)

> Les services à redémarrer sont les services de l’instance concernés. Ex, sur la photo: si l’instance se nomme MSSQLSERVER (Protocols for MSSQLSERVER), le service à redémarrer est le service: SQL server MSSQLSERVER (si le service n’est pas listés dans l’onglet, le redémarrer via l’outil “services”)
> 

![Untitled](Untitled%204.png)

- TCP (sql) est configuré sur le port 1433, il va falloir maintenant l’autoriser
    - ouvrir windows firewall
    - ajouter une nouvelle règle
    - choisir l’option port
    - entrer le port 1433
        
        ![Untitled](Untitled%205.png)
        
        ![Untitled](Untitled%206.png)
        
        ![Untitled](Untitled%207.png)
        
- Ajout de l’application SQL Server à autoriser également
    - cliquer sur nouvelle règele dans windows firewall
    - choisir personnalisé (custom)
    - choisir le bouton personnalisation (customize)
    - choisir l’option “appliquer à ce service”
        - rechercher le service “SQL server EBP (dans notre cas)”

![Untitled](Untitled%208.png)

![Untitled](Untitled%209.png)

![Untitled](Untitled%2010.png)

![Untitled](Untitled%2011.png)

![Untitled](Untitled%2012.png)